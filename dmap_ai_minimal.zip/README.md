# DMAP-AI API (demo)

Minimal FastAPI service for Render.

## Run locally
```
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Then open: http://127.0.0.1:8000/health and http://127.0.0.1:8000/docs
